WITH TB_BASE_DATA AS ( SELECT TO_CHAR(TO_DATE(T.INPUT_TIME,'YYYYMMDDHH24MISS') - 12/24 ,'YYYY.MM.DD' ) AS BASE_DATE 
                              ,SUBSTR(INPUT_TIME, 1,11) AS BT_TIME , T.INDUCT_NO,COUNT(*) AS CNT 
                         FROM MT_SORT_RESULT T
                        WHERE EQP_CD LIKE 'MS%'
                          AND T.INPUT_TIME BETWEEN  TO_CHAR(SYSDATE - 1,'YYYYMMDD')||'190000' AND TO_CHAR(SYSDATE - 0,'YYYYMMDD')||'120000'
                         /* AND SUBSTR(T.INPUT_TIME,1,8) IN ( \*'20210914', '20210915', '20210923', '20210924', '20210927', '20210928'
                                                              ,'20211005', '20211006', '20211012', '20211013', '20211018', '20211019'
                                                              ,'20211025', '20211026', '20211101', '20211102', '20211108', '20211109'                                     
                                                              ,'20211115', '20211116', '20211122', '20211123'                                    
                                                              ,'20211129', '20211130', '20211201'
                                                              ,'20211206', '20211207', '20211208' 
                                                              ,'20211213', '20211214', '20211215' 
                                                              ,'20211220', '20211221', '20211222' 
                                                              ,'20211227', '20211228', '20211229' 
                                                              ,'20220103', '20220104', '20220105'*\
                                                               '20220110', '20220111'
                                                             \* ,'20220117', '20220118'*\
                                                             )
                            AND  SUBSTR(T.INPUT_TIME,9,2) in ( '00','01','02','03','04','05','06','07','08','09','10','11','12','19','20','21','22','23' )*/
                       GROUP BY TO_CHAR(TO_DATE(T.INPUT_TIME,'YYYYMMDDHH24MISS') - 12/24 ,'YYYY.MM.DD' )
                      ,SUBSTR(INPUT_TIME, 1,11),INDUCT_NO  )
  
  SELECT BASE_DATE
        ,NVL(SUBSTR(BT_TIME,5,4)||'-'||SUBSTR(BT_TIME,9,3),'001TOTAL') AS D_TIME 
        ,' ' AS �ߴ����Ұ�
        ,' ' AS MSA��
        ,' ' AS SUB��
        ,SUM( CASE WHEN INDUCT_NO = '811' THEN CNT ELSE 0 END ) AS "811"  -- A
        ,SUM( CASE WHEN INDUCT_NO = '812' THEN CNT ELSE 0 END ) AS "812"
        ,SUM( CASE WHEN INDUCT_NO = '813' THEN CNT ELSE 0 END ) AS "813"
         ,' ' AS SUB��
        ,SUM( CASE WHEN INDUCT_NO = '821' THEN CNT ELSE 0 END ) AS "821"
        ,SUM( CASE WHEN INDUCT_NO = '822' THEN CNT ELSE 0 END ) AS "822"
        ,SUM( CASE WHEN INDUCT_NO = '823' THEN CNT ELSE 0 END ) AS "823"
        ,' ' AS MSB��
        ,' ' AS SUB��
        ,SUM( CASE WHEN INDUCT_NO = '711' THEN CNT ELSE 0 END ) AS "711" -- B
        ,SUM( CASE WHEN INDUCT_NO = '712' THEN CNT ELSE 0 END ) AS "712"
        ,SUM( CASE WHEN INDUCT_NO = '713' THEN CNT ELSE 0 END ) AS "713"
         ,' ' AS SUB��
        ,SUM( CASE WHEN INDUCT_NO = '721' THEN CNT ELSE 0 END ) AS "721"
        ,SUM( CASE WHEN INDUCT_NO = '722' THEN CNT ELSE 0 END ) AS "722"
        ,SUM( CASE WHEN INDUCT_NO = '723' THEN CNT ELSE 0 END ) AS "723"
        ,' ' AS MSC��
        ,' ' AS SUB��
        ,SUM( CASE WHEN INDUCT_NO = '411' THEN CNT ELSE 0 END ) AS "411"  -- C
        ,SUM( CASE WHEN INDUCT_NO = '412' THEN CNT ELSE 0 END ) AS "412"
        ,SUM( CASE WHEN INDUCT_NO = '413' THEN CNT ELSE 0 END ) AS "413"
         ,' ' AS SUB��
        ,SUM( CASE WHEN INDUCT_NO = '421' THEN CNT ELSE 0 END ) AS "421"
        ,SUM( CASE WHEN INDUCT_NO = '422' THEN CNT ELSE 0 END ) AS "422"
        ,SUM( CASE WHEN INDUCT_NO = '423' THEN CNT ELSE 0 END ) AS "423"
        ,' ' AS MSD��
        ,' ' AS SUB��
        ,SUM( CASE WHEN INDUCT_NO = '311' THEN CNT ELSE 0 END ) AS "311" -- D
        ,SUM( CASE WHEN INDUCT_NO = '312' THEN CNT ELSE 0 END ) AS "312"
        ,SUM( CASE WHEN INDUCT_NO = '313' THEN CNT ELSE 0 END ) AS "313"
         ,' ' AS SUB��
        ,SUM( CASE WHEN INDUCT_NO = '321' THEN CNT ELSE 0 END ) AS "321"
        ,SUM( CASE WHEN INDUCT_NO = '322' THEN CNT ELSE 0 END ) AS "322"
        ,SUM( CASE WHEN INDUCT_NO = '323' THEN CNT ELSE 0 END ) AS "323"
        ,' ' AS MSE��
        ,' ' AS SUB��
        ,SUM( CASE WHEN INDUCT_NO = '211' THEN CNT ELSE 0 END ) AS "211" -- E
        ,SUM( CASE WHEN INDUCT_NO = '212' THEN CNT ELSE 0 END ) AS "212"
        ,SUM( CASE WHEN INDUCT_NO = '213' THEN CNT ELSE 0 END ) AS "213"
         ,' ' AS SUB��
        ,SUM( CASE WHEN INDUCT_NO = '221' THEN CNT ELSE 0 END ) AS "221"
        ,SUM( CASE WHEN INDUCT_NO = '222' THEN CNT ELSE 0 END ) AS "222"
        ,SUM( CASE WHEN INDUCT_NO = '223' THEN CNT ELSE 0 END ) AS "223"
        ,' ' AS MSF��
        ,' ' AS SUB��
        ,SUM( CASE WHEN INDUCT_NO = '111' THEN CNT ELSE 0 END ) AS "111"  -- F
        ,SUM( CASE WHEN INDUCT_NO = '112' THEN CNT ELSE 0 END ) AS "112"
        ,SUM( CASE WHEN INDUCT_NO = '113' THEN CNT ELSE 0 END ) AS "113"
         ,' ' AS SUB��
        ,SUM( CASE WHEN INDUCT_NO = '121' THEN CNT ELSE 0 END ) AS "121"
        ,SUM( CASE WHEN INDUCT_NO = '122' THEN CNT ELSE 0 END ) AS "122"
        ,SUM( CASE WHEN INDUCT_NO = '123' THEN CNT ELSE 0 END ) AS "123"
   FROM TB_BASE_DATA
  GROUP BY BASE_DATE,ROLLUP(SUBSTR(BT_TIME,5,4)||'-'||SUBSTR(BT_TIME,9,3)) 
